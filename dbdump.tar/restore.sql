--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.10 (Ubuntu 10.10-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.10 (Ubuntu 10.10-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.orders DROP CONSTRAINT orders_pkey;
DROP TABLE public.orders;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.orders (
    id character(128) NOT NULL,
    user_id character(128) NOT NULL,
    vehicle_model_id character(128) NOT NULL,
    package_id integer,
    travel_type_id integer,
    from_area_id character(128),
    to_area_id character(128),
    from_city_id character(128),
    to_city_id character(128),
    from_date integer,
    to_date integer,
    online_booking boolean,
    mobile_site_booking boolean,
    booking_created integer,
    from_lat numeric(11,8),
    from_long numeric(11,8),
    to_lat numeric(11,8),
    to_long numeric(11,8),
    car_cancellation boolean
);


ALTER TABLE public.orders OWNER TO ghost;

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.orders (id, user_id, vehicle_model_id, package_id, travel_type_id, from_area_id, to_area_id, from_city_id, to_city_id, from_date, to_date, online_booking, mobile_site_booking, booking_created, from_lat, from_long, to_lat, to_long, car_cancellation) FROM stdin;
\.
COPY public.orders (id, user_id, vehicle_model_id, package_id, travel_type_id, from_area_id, to_area_id, from_city_id, to_city_id, from_date, to_date, online_booking, mobile_site_booking, booking_created, from_lat, from_long, to_lat, to_long, car_cancellation) FROM '$$PATH$$/3032.dat';

--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

